#include<windows.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
void display(void)
{
///robot
///head circle
float theta;
int i;
glColor3f(204, 0, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(400+20*cos(theta),510+20*sin(theta));
	}
	glEnd();
///triangle
glColor3ub (230, 230, 0);
glBegin(GL_POLYGON);
glVertex2d (400, 510);
glVertex2d (370,480);
glVertex2d (430, 480);
glEnd();
///face
glColor3ub (153, 153, 102);
glBegin(GL_POLYGON);
glVertex2d (300, 480);
glVertex2d (500,480);
glVertex2d (500, 390);
glVertex2d (300, 390);
glEnd();
///eyes
glColor3f(0, 0, 204);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(350+10*cos(theta),450+10*sin(theta));
	}
	glEnd();
glColor3f(0, 0, 204);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(450+10*cos(theta),450+10*sin(theta));
	}
	glEnd();
///mouth
glColor3ub (107, 107, 71);
glBegin(GL_POLYGON);
glVertex2d (290, 438);
glVertex2d (310, 438);
glVertex2d (350, 420);
glVertex2d (450, 420);
glVertex2d (490, 438);
glVertex2d (510, 438);
glVertex2d (510, 390);
glVertex2d (290, 390);
glEnd();
///lips
glColor3ub (224, 224, 209);
glBegin(GL_POLYGON);
glVertex2d (350, 408);
glVertex2d (450, 408);
glVertex2d (450, 402);
glVertex2d (350, 402);
glEnd();
///neck
glColor3ub (152, 152, 103);
glBegin(GL_POLYGON);
glVertex2d (370, 390);
glVertex2d (430, 390);
glVertex2d (430, 360);
glVertex2d (370, 360);
glEnd();
///body
glColor3ub (204, 102, 0);
glBegin(GL_POLYGON);
glVertex2d (250, 360);
glVertex2d (550, 360);
glVertex2d (550, 210);
glVertex2d (250, 210);
glEnd();
///monitor
glColor3ub (245, 245, 240);
glBegin(GL_POLYGON);
glVertex2d (280, 342);
glVertex2d (520, 342);
glVertex2d (520, 270);
glVertex2d (280, 270);
glEnd();
///triangle of monitor
glColor3ub (13, 13, 13);
glBegin(GL_POLYGON);
glVertex2d (400, 330);
glVertex2d (350, 300);
glVertex2d (450, 300);
glEnd();
///buttons
glColor3ub (0, 77, 0);
glBegin(GL_POLYGON);
glVertex2d (300, 252);
glVertex2d (320,252);
glVertex2d (320, 240);
glVertex2d (300, 240);
glEnd();
glColor3ub (128, 0, 0);
glBegin(GL_POLYGON);
glVertex2d (350, 252);
glVertex2d (370,252);
glVertex2d (370, 240);
glVertex2d (350, 240);
glEnd();

glColor3ub (0, 230, 0);
glBegin(GL_POLYGON);
glVertex2d (390, 252);
glVertex2d (410,252);
glVertex2d (410, 240);
glVertex2d (390, 240);
glEnd();
glColor3ub (0, 0, 153);
glBegin(GL_POLYGON);
glVertex2d (430, 252);
glVertex2d (450,252);
glVertex2d (450, 240);
glVertex2d (430, 240);
glEnd();
glColor3ub (102, 0, 102);
glBegin(GL_POLYGON);
glVertex2d (470, 252);
glVertex2d (490,252);
glVertex2d (490, 240);
glVertex2d (470, 240);
glEnd();
///legs
glColor3ub (107, 107, 71);
glBegin(GL_POLYGON);
glVertex2d (300, 210);
glVertex2d (370, 210);
glVertex2d (370, 120);
glVertex2d (300, 120);
glEnd();
glColor3ub (107, 107, 71);
glBegin(GL_POLYGON);
glVertex2d (430, 210);
glVertex2d (500, 210);
glVertex2d (500, 120);
glVertex2d (430, 120);
glEnd();
///shoes
glColor3ub (185, 185, 146);
glBegin(GL_POLYGON);
glVertex2d (280, 120);
glVertex2d (390, 120);
glVertex2d (390, 90);
glVertex2d (280, 90);
glEnd();
glColor3ub (185, 185, 146);
glBegin(GL_POLYGON);
glVertex2d (410, 120);
glVertex2d (520, 120);
glVertex2d (520, 90);
glVertex2d (410, 90);
glEnd();
glFlush ();
}
void init (void)
{
glClearColor (1.0, 0.0, 1.0,0.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0, 1200, 0, 600);
}
int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (1200, 600);
glutInitWindowPosition (0,0);
glutCreateWindow ("Sarmistha(171-15-9306)");
init ();
glutDisplayFunc(display);
glutMainLoop();
return 0;
}
